#Creator ( XyrooOFC )
©2025 - Xyroo

ini adalah base bot whatsapp simple buatanku jadi pakai aja kalau kamu tertarik.


#Developer ( XyrooOFC )
©2025 - Xyroo

This is my simple WhatsApp bot base, so feel free to use it if you're interested.
